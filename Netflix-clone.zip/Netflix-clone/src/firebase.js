import { initializeApp } from "firebase/app";
import { createUserWithEmailAndPassword, getAuth, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { addDoc, collection, getFirestore } from "firebase/firestore";
import { toast } from "react-toastify";

const firebaseConfig = {
  apiKey: "AIzaSyAQfKYOaf5YdaodnB8hWuzHftzBFSq5NSE",
  authDomain: "netflix-clone-9c4ab.firebaseapp.com",
  projectId: "netflix-clone-9c4ab",
  storageBucket: "netflix-clone-9c4ab.firebasestorage.app",
  messagingSenderId: "611019428572",
  appId: "1:611019428572:web:d018aea17ef2a4e6185a19"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const signup = async (name, email, password)=>{
    try {
        const res =await createUserWithEmailAndPassword(auth, email, password );
        const user = res.user;
        await addDoc(collection(db, "user"), {
            uid: user.uid,
            name,
            authProvider: "local",
            email,


        });
    } catch (error) {
        console.log(error);
        toast.error(error.code.split('/')[1].split('-').join(" "));
        
    }

}

const login = async (email,password)=>{

    try {
        await signInWithEmailAndPassword(auth, email, password)
    } catch (error) {

        console.log(error);
        toast.error(error.code.split('/')[1].split('-').join(" "));
        
    }

}

const logout = ()=>{
    signOut(auth);
}

export {auth,db, login, signup, logout};